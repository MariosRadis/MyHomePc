﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
namespace IndividualProjectRev3
{
   public class TakeTemperatureAndHumidityFromSerial
    {
        public string TempAndHum()
        {
            // List<string> tempAndHum = new List<string>();
            try
            {
                SerialPort mySerialPort = new SerialPort("COM3");

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None;
                mySerialPort.StopBits = StopBits.One;
                mySerialPort.DataBits = 8;
                mySerialPort.Handshake = Handshake.None;
                mySerialPort.RtsEnable = true;
                mySerialPort.Open();
          
            mySerialPort.Write("400,400,400\n");

            string temp = mySerialPort.ReadLine();
           // Console.WriteLine(temp);
           

            mySerialPort.Close();

           
            return temp;
            }
            catch
            {
               
                return "could not connect to com";
            }


        }
    }
}
