﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace IndividualProjectRev3
{
    class MakeACoffee
    {
        private string TurnCoffeeMachineOn = "500,500,500\n";
        private string TurnCoffeeMachineOff = "501,501,501\n";
        private string CheckForWaterLvl = "550,550,550\n";
        private string CheckIfWaterIsHeatedUp = "600,600,600\n";
        private string MakeEspressoRistreto = "700,700,700\n";
        private string MakeEspressoLungo = "501,501,501\n";

        public void TurnOnTheCoffeeMachine()
        {
            SerialPort mySerialPort = new SerialPort("COM3");
            mySerialPort.BaudRate = 9600;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;
            mySerialPort.RtsEnable = true;
            //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            mySerialPort.Open();

            mySerialPort.Write(TurnCoffeeMachineOn);

            mySerialPort.Close();

        }
        public void TurnOffTheCoffeeMachine()
        {
            SerialPort mySerialPort = new SerialPort("COM3");
            mySerialPort.BaudRate = 9600;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;
            mySerialPort.RtsEnable = true;
            //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            mySerialPort.Open();

            mySerialPort.Write(TurnCoffeeMachineOff);

            mySerialPort.Close();
        }
        public string CheckWaterLvl()
        {
            SerialPort mySerialPort = new SerialPort("COM3");
            mySerialPort.BaudRate = 9600;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;
            mySerialPort.RtsEnable = true;
            //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            mySerialPort.Open();
            mySerialPort.Write(CheckForWaterLvl);


            string WaterLvl = mySerialPort.ReadLine();

            mySerialPort.Close();
            return WaterLvl;

        }
        public string CheckWaterHeat()
        {
            SerialPort mySerialPort = new SerialPort("COM3");
            mySerialPort.BaudRate = 9600;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;
            mySerialPort.RtsEnable = true;
            //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            mySerialPort.Open();
            mySerialPort.Write(CheckIfWaterIsHeatedUp);
            string IsWaterHeated = mySerialPort.ReadLine();

            mySerialPort.Close();
            return IsWaterHeated;

        }
        public void MakeARistrettoEspresso()
        {
            SerialPort mySerialPort = new SerialPort("COM3");
            mySerialPort.BaudRate = 9600;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;
            mySerialPort.RtsEnable = true;
            //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            mySerialPort.Open();

            mySerialPort.Write(MakeEspressoRistreto);

            mySerialPort.Close();
        }
        public void MakeALungoEspresso()
        {
            SerialPort mySerialPort = new SerialPort("COM3");
            mySerialPort.BaudRate = 9600;
            mySerialPort.Parity = Parity.None;
            mySerialPort.StopBits = StopBits.One;
            mySerialPort.DataBits = 8;
            mySerialPort.Handshake = Handshake.None;
            mySerialPort.RtsEnable = true;
            //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            mySerialPort.Open();

            mySerialPort.Write(MakeEspressoLungo);

            mySerialPort.Close();
        }
    }
}
