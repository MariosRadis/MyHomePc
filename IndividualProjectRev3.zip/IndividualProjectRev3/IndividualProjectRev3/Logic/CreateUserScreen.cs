﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    public class Createuser
    {
        public void TakeUsers(List<User> User)
        {
            List<User> _list = new List<User>();
            User user = new User();
            UserManager u = new UserManager();
            _list = u.GetAllUsers();
            Console.Write("Give me a Username: ");
            string NewUser = Console.ReadLine();
            var exsusr = false;
            //tsekaro an to username einai keno i ligotero apo 3 xaraktires
            while (true)
            {
                exsusr = _list.Exists(p => p.UserName == NewUser);
                if (NewUser != null && NewUser.Count() < 4)
                {
                    MessageBox.Show("Username must not be null or less than three charachters");
                    Console.Write("Give me a Username: ");
                    NewUser = Console.ReadLine();
                }
                else if (exsusr == true)
                {
                    Console.WriteLine("This username allready exists");
                    Console.Write("Give me a Username: ");
                    NewUser = Console.ReadLine();
                }
                else
                    break;
            }
            user.UserName = NewUser;
            // here i take the password.
            string Password = null;
            Console.WriteLine("Password length must be at least 6 characters long, contains at least one digit and contains at least one upper case alphabet");
            Console.Write("Give me a Password: ");                       
            Password = Console.ReadLine();  
            var hasNumber = new Regex(@"[0-9]+");
            var hasUpperChar = new Regex(@"[A-Z]+");
            var hasMinimum8Chars = new Regex(@".{6,}");
            //here i check if the password is 6 chars long at least one number one upper case
            while (true) 
            {
                
                if (Password != "")
                {
                    if (!hasNumber.IsMatch(Password) || !hasUpperChar.IsMatch(Password) || !hasMinimum8Chars.IsMatch(Password))
                    {
                        MessageBox.Show("Password length must be at least 6 characters long, contains at least one digit and contains at least one Upper case alphabet");
                        Console.Write("Give me a Password: ");
                        Password = Console.ReadLine();
                    }
                    else
                    {
                        break; //when pass is valid.
                    }
                }
                else
                {
                    MessageBox.Show("Password cant be null");//when password is null.
                    Console.Write("Give me a Password: ");
                    Password = Console.ReadLine();
                }
            }
            //encrypt the pass
            var salt = Passhash.GetSalt();
            var hash = Passhash.Hash(Password, salt);
            user.HashedPass = hash;
            user.Salt = salt;         
            Console.WriteLine("Give me your e-mail");  //here i take the mail.
            string EmailAddress = Console.ReadLine();
            MailManager mail = new MailManager();
            bool ValidMail = mail.IsValid(EmailAddress);
            //Here i check if this is a valid mail.        
            while (!ValidMail)
            {
                Console.WriteLine("this is not a mail a mail must have mail@domain.com form"); 
                EmailAddress = Console.ReadLine();
                ValidMail = mail.IsValid(EmailAddress);
            }
            user.EmailAddress = EmailAddress;
            UserManager userNew = new UserManager();
            userNew.CreateUser(user.UserName, user.EmailAddress,user.HashedPass,user.Salt);
            _list = userNew.GetAllUsers();
            User = _list;
        }
    }
}
