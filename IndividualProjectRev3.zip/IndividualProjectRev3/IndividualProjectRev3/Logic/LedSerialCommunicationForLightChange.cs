﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;
namespace IndividualProjectRev3
{
    public class LedSerialCommunicationForLightChange
    {

        private string white = "255,255,255\n";
        private string DarkBlue = "0,0,128\n";
        private string DarkGreen = "0,128,0\n";
        private string DarkCyan = "0,128,128\n";
        private string DarkRed = "128,0,0\n";
        private string DarkMagenta = "128,0,128\n";
        private string DarkYellow = "128,128,0\n";
        private string Gray = "192,192,192\n";
        private string DarkGray = "128,128,128\n";
        private string Blue = "0,0,255\n";
        private string Green = "0,255,0\n";
        private string Cyan = "0,255,255\n";
        private string Red = "255,0,0\n";
        private string Magenta = "255,0,255\n";
        private string Yellow = "255,255,0\n";
        private string TurnOff = "0,0,0\n";


        public void SetRoomLight(int ColorNumber)
        {
            try
            {
                SerialPort mySerialPort = new SerialPort("COM3");

                mySerialPort.BaudRate = 9600;
                mySerialPort.Parity = Parity.None;
                mySerialPort.StopBits = StopBits.One;
                mySerialPort.DataBits = 8;
                mySerialPort.Handshake = Handshake.None;
                mySerialPort.RtsEnable = true;
                //  mySerialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                mySerialPort.Open();

                switch (ColorNumber)
                {
                    case 1:
                        mySerialPort.Write(white);
                        break;
                    case 2:
                        mySerialPort.Write(DarkBlue);
                        break;
                    case 3:
                        mySerialPort.Write(DarkGreen);
                        break;
                    case 4:
                        mySerialPort.Write(DarkCyan);
                        break;
                    case 5:
                        mySerialPort.Write(DarkRed);
                        break;
                    case 6:
                        mySerialPort.Write(DarkMagenta);
                        break;
                    case 7:
                        mySerialPort.Write(DarkYellow);
                        break;
                    case 8:
                        mySerialPort.Write(Gray);
                        break;
                    case 9:
                        mySerialPort.Write(DarkGray);
                        break;
                    case 10:
                        mySerialPort.Write(Blue);
                        break;
                    case 11:
                        mySerialPort.Write(Green);
                        break;
                    case 12:
                        mySerialPort.Write(Cyan);
                        break;
                    case 13:
                        mySerialPort.Write(Red);
                        break;
                    case 14:
                        mySerialPort.Write(Magenta);
                        break;
                    case 15:
                        mySerialPort.Write(Yellow);
                        break;
                    case 16:
                        mySerialPort.Write(TurnOff);
                        break;
                }
                mySerialPort.Close();
            }
            catch
            {
                MessageBox.Show("Could not connect to device please try again later");
            }
        }

    }
}
