﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    public class LoginScreen
    {
        public void GotoLoginScreen() // Here is the menu when you want to log in
        {
            Console.WriteLine("Username:");
            string user = Console.ReadLine();       
            UserMatchup userMatchup = new UserMatchup();
            bool usermatch=userMatchup.UsernameMatch(user);
            if (!usermatch)
                MessageBox.Show("This username does not exist");
            else if (usermatch)
            {
                Console.WriteLine("Password: ");  
                
                string pass=null;    // stars in order not to see the pass
                while (true)
                {
                    var k = Console.ReadKey();
                    if (k.Key==ConsoleKey.Enter)
                    {
                        break;
                    }
                    else if (k.Key!=ConsoleKey.Backspace)
                    {
                        Console.Write("\b");
                        Console.Write("*");
                        pass += k.KeyChar;
                    }
                    else
                    {
                        if (pass.Length>0)
                        {                                           
                        Console.Write(" ");
                        Console.Write("\b");
                        pass = pass.Remove(pass.Length - 1);
                        }
                    }
                   

                }
                bool passmatch = false;
                if (pass!=null)
                {
                 passmatch = userMatchup.PasswordMatch(user, pass);             
                }
                if (!passmatch) //wrong pass                            
                    MessageBox.Show("The password is wrong ", "MyHomePc", MessageBoxButtons.OK);   
                else if (passmatch) //right pass
                {
                    MessageBox.Show("The password is right ", "MyHomePc", MessageBoxButtons.OK);
                    LoggerManager log = new LoggerManager();                     //log the time that someone logged in
                    log.LogUser(user);
                    UserManager userManager = new UserManager();
                    StaticProperties.AppConsoleColor= userManager.FindBackgroundByUserId(StaticProperties.LoggedUserId);
                    StaticProperties.AppHightLightColor = userManager.FindHightLightColorByUserId(StaticProperties.LoggedUserId);
                    int AccesLvL=userManager.CheckLvLOffAccess(user);
                    UserFirstScreen s = new UserFirstScreen();
                    if (AccesLvL == 0)//simple user
                        s.PrintFirstScreen();
                    else if (AccesLvL == 1)
                        UserWithAccessLvL1Screen.PrintAdminLvL1FirstScreen();
                    else if (AccesLvL == 2)
                        UserWithAccessLvL2Screen.PrintAdminLvL2FirstScreen();
                    else if (AccesLvL == 3)
                        UserWithAccessLvL3Screen.PrintAdminLvL3FirstScreen();
                    else if (AccesLvL==4)//Admin
                        AdminFirstScreen.PrintAdminFirstScreen();
                }
            }
        }
    }
}
