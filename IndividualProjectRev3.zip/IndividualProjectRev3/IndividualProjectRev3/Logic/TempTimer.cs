﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;


namespace IndividualProjectRev3
{
    class TemperatureTimer
    {
        private static Timer aTimer;

        public static void Timer()
        {
            SetTimer();

         
        }
        private static void SetTimer()
        {
            // Create a timer with a two second interval.
            aTimer = new Timer(StaticProperties.TimeForTempLogMillisec);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }
        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
          
            //kalese tin methodo write add temp to file
            string Tolog;
            TemperatureHumidityFileLogger t = new TemperatureHumidityFileLogger();
            TakeTemperatureAndHumidityFromSerial data = new TakeTemperatureAndHumidityFromSerial();
            Tolog= data.TempAndHum();
            t.LogTempHum(DateTime.Now, Tolog);
        }
    }
}
