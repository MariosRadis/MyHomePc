﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    class NewMessageEvent
    {
        private static System.Timers.Timer bTimer;

        public static void TimerForNewMessage()
        {
            SetTimer();

         
        }
        public static void KillTimerForNewMessage()
        {
            bTimer.Stop();
            bTimer.Dispose();


        }
        private static void SetTimer()
        {
            // Create a timer with a two second interval.
            bTimer = new System.Timers.Timer(1000);
            // Hook up the Elapsed event for the timer. 
            bTimer.Elapsed += OnTimedEvent;
            bTimer.AutoReset = true;
            bTimer.Enabled = true;
        }
        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            MessageManager count = new MessageManager();
            //check if you have a new message
            if (StaticProperties.MessageCountForUser!=count.CountMessagesByUserId(StaticProperties.LoggedUserId))
            {
                StaticProperties.MessageCountForUser = count.CountMessagesByUserId(StaticProperties.LoggedUserId);             
                DialogResult res = MessageBox.Show("You have a new Message go to Messages?", "New Message");        
            }
        }
    }
}
