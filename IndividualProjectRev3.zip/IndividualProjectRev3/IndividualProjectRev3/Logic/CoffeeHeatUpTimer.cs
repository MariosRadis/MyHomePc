﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
   public class CoffeeHeatUpTimer
    {
        private static System.Timers.Timer CoffeeTimer;

        public static void Timer()
        {
            SetTimer();
        }
        public static void KillTimerCoffeeHeat()
        {
            CoffeeTimer.Stop();
            CoffeeTimer.Dispose();
        }
        private static void SetTimer()
        {
            // Create a timer with a two second interval.
            CoffeeTimer = new System.Timers.Timer(500);
            // Hook up the Elapsed event for the timer. 
            CoffeeTimer.Elapsed += OnTimedEvent;
            CoffeeTimer.AutoReset = true;
            CoffeeTimer.Enabled = true;
        }
        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            MakeACoffee coffee = new MakeACoffee();
            string heat = coffee.CheckWaterHeat();
            if (heat=="1\r")
            {
                KillTimerCoffeeHeat();
                DialogResult choice= MessageBox.Show("The water is heated make a coffee?", "Coffee Time!!!", MessageBoxButtons.YesNo);
                if (DialogResult.Yes==choice)
                {
                    coffee.MakeARistrettoEspresso();
                   
                }            
            }         
        }
    }
}
