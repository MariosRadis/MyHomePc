﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndividualProjectRev3
{
    public  class Logger
    {
        public int Id { get; set; }
        public string LoggedUser { get; set; }
        public DateTimeOffset LoggerTime { get; set; }

    }
}
