﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
   public static class StaticProperties
    {

        static public int LoggedUserId { get; set; }
        static public string LoggedUserName { get; set; }
        static public int AppConsoleColor { get; set; }
        static public int AppMenuChoicesColor { get; set; }
        static public int AppHightLightColor { get; set; }
        static public int TimeForTempLogMillisec { get; set; }
        static public int MessageCountForUser { get; set; }
        static public bool IsSomeoneLogged { get; set; }

    }
}
