﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    public class User
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int LevelOfAccess { get; set; }
        public string EmailAddress { get; set; }
        public int AppConsoleColor { get; set; }
        public int AppMenuChoicesColor { get; set; }
        public int AppHightLightColor { get; set; }
        public byte[] HashedPass { get; set; }
        public byte[] Salt { get; set; }
        public int ProfileStatus { get; set; }

        //enas user exei polla minimata
        //navigation property
        public virtual ICollection<Message> Messages { get; set; }



    }
}
