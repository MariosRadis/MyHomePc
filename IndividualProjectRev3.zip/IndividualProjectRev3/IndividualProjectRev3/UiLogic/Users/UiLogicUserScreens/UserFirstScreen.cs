﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    public class UserFirstScreen
    {
      

        public void PrintFirstScreen()
        {
            StaticProperties.IsSomeoneLogged = true;
            MessageManager counts = new MessageManager();
            StaticProperties.MessageCountForUser = counts.CountMessagesByUserId(StaticProperties.LoggedUserId);
            // here i start the timer tha tells me if i have a new message
            NewMessageEvent.TimerForNewMessage();      
            int MenuChoice = 0;
            while (MenuChoice != 6)
            {

                List<User> _users = new List<User>();
                List<Message> MyMessageList = new List<Message>();
                UserManager _listOfAllUsers = new UserManager();

                List<string> MenuList = new List<string>() { "View all users", "Read messages", "Send message", "Extra Features","Change Password", "Logout" };
                PrintsForMenuScreen l = new PrintsForMenuScreen(MenuList);
                MenuChoice = l.ArrowsForFirstScreen(MenuList);
                switch (MenuChoice)
                {
                    case 1:
                        _users = _listOfAllUsers.GetAllUsers();
                        PrintsForMenuScreen k = new PrintsForMenuScreen(_users);
                        k.ArrowsForFirstScreen(_users);
                        break;
                    case 2:
                        UiLogicUserAccess us = new UiLogicUserAccess();
                        us.ReadMessage();
                        break;
                    case 3:
                        UiLogicUserAccess user = new UiLogicUserAccess();
                        user.SendMessage();
                        break;
                    case 4:
                        UserExtrasScreen e = new UserExtrasScreen();
                        e.UserExtraPrint();                       
                        break;
                    case 5:
                        UiLogicUserAccess r = new UiLogicUserAccess();
                            r.ChangePassword();
                        break;
                }
            }
            //KILL TIMER 
            NewMessageEvent.KillTimerForNewMessage();
            StaticProperties.IsSomeoneLogged = false;

        }
    }
}
