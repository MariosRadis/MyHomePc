﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace IndividualProjectRev3
{
    class UserExtrasScreen
    {
        public void UserExtraPrint()
        {
            int Menuchoice = 0;
            while (Menuchoice != 5)
            {
                List<string> MenuList = new List<string>() { "Select background color", "Select menu highlight color", "LightMyRoom","Make me a coffee", "Return" };
                PrintsForMenuScreen s = new PrintsForMenuScreen(MenuList);
                Menuchoice = s.ArrowsForFirstScreen(MenuList);
                int Menuchoice2 = 0;
                int Menuchoice3 = 0;
                int Menuchoice4 = 0;
                int Menuchoice5 = 0;
                if (Menuchoice != 5)
                {
                    while (Menuchoice2 != 16 && Menuchoice3 != 16&& Menuchoice4!=17&&Menuchoice5!=3)
                    {
                        switch (Menuchoice)
                        {
                            case 1:
                                //Xromata sto background tou kathenos
                                List<string> MenuList2 = new List<string>() { "Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "Gray", "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "Return" };
                                PrintsForMenuScreen l = new PrintsForMenuScreen(MenuList2);
                                Menuchoice2 = l.ArrowsForFirstScreen(MenuList2);
                                if (Menuchoice2 != 16)
                                {
                                    if (Menuchoice2 - 1 == StaticProperties.AppHightLightColor)
                                    {

                                        MessageBox.Show("Highlight color and background color can not be the same");


                                    }
                                    else
                                    {

                                        StaticProperties.AppConsoleColor = Menuchoice2 - 1;
                                        UserManager m = new UserManager();
                                        m.UpdateBackgroundColorByUserId(StaticProperties.LoggedUserId, Menuchoice2 - 1);
                                    }
                                }
                                break;

                            case 2:
                                // Colors that highlight the menu choice
                                List<string> MenuList3 = new List<string>() { "Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "Gray", "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "Return" };
                                PrintsForMenuScreen k = new PrintsForMenuScreen(MenuList3);
                                Menuchoice3 = s.ArrowsForFirstScreen(MenuList3);
                                if (Menuchoice3 != 16)
                                {
                                    if (Menuchoice3 != 8)
                                    {
                                        if (Menuchoice3-1 == StaticProperties.AppConsoleColor)
                                        {

                                            MessageBox.Show("Highlight color and background color can not be the same");


                                        }
                                        else
                                        {
                                            StaticProperties.AppMenuChoicesColor = Menuchoice3 - 1;
                                            UserManager m = new UserManager();
                                            m.UpdateAppHightLightColor(StaticProperties.LoggedUserId, Menuchoice3 - 1);
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Grey is not supported");
                                    }
                                }
                                break;

                            case 3:
                                //ftiakse mia lista me default xromata gia to led
                                List<string> MenuList4 = new List<string>() { "White", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "Gray", "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "Turn off","Return" };
                                PrintsForMenuScreen z = new PrintsForMenuScreen(MenuList4);
                                Menuchoice4 = z.ArrowsForFirstScreen(MenuList4);
                                //edo tha kaleso ti methodo pou allazei xroma sto led mou
                                LedSerialCommunicationForLightChange led = new LedSerialCommunicationForLightChange();
                                led.SetRoomLight(Menuchoice4);
                                break;

                            case 4:
                                List<string> MenuList5 = new List<string>() {"Make an Espresso","Shut down the coffee machine", "Return" };
                                PrintsForMenuScreen c = new PrintsForMenuScreen(MenuList5);
                                Menuchoice5 = c.ArrowsForFirstScreen(MenuList5);
                                MakeACoffee coffee = new MakeACoffee();
                                if (Menuchoice5 == 1)
                                {
                                    string water = coffee.CheckWaterLvl();
                                    Console.WriteLine(water);
                                    if (water=="1\r")                                      
                                    {
                                        MessageBox.Show("The program will make you know whem the water is heated up");
                                        coffee.TurnOnTheCoffeeMachine();
                                        Thread.Sleep(1000);
                                        CoffeeHeatUpTimer.Timer();
                                        
                                        
                                        
                                    }
                                    else if(water == "0\r")
                                    {
                                        MessageBox.Show("The water tank of the coffe machine is empty");
                                    }
                                   
                                

                                }
                                else if (Menuchoice5 == 2)
                                {
                                    coffee.TurnOffTheCoffeeMachine();
                                }
                             
                                break;
                        }
                    }
                }
            }
        }
    }
}
