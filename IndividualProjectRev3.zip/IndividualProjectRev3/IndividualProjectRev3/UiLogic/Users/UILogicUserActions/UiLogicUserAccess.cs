﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    class UiLogicUserAccess
    {

        protected List<User> _users = new List<User>();
        protected UserManager _listOfAllUsers = new UserManager();
        protected List<Message> MyMessageList = new List<Message>();

        internal protected void ViewAllUsers()
        {
            _users = _listOfAllUsers.GetAllUsers();
            PrintsForMenuScreen k = new PrintsForMenuScreen(_users);
            k.ArrowsForFirstScreen(_users);
        }
        internal protected void ReadMessage()
        {

            MessageManager mes = new MessageManager();
            MyMessageList = mes.FindMessagesByUserId(StaticProperties.LoggedUserId).ToList();
            if (MyMessageList.Count() == 0)
            {
                MessageBox.Show("You dont have any messages");

            }
            else
            {
                PrintsForMenuScreen z = new PrintsForMenuScreen(MyMessageList);
                z.ArrowsForFirstScreen(MyMessageList);
            }
        }
        internal protected void SendMessage()
        {
            Console.Clear();
            PrintLogo.MessagemyWord();
            Console.Clear();
            UserManager Receiveuser = new UserManager();
            List<User> listofusers = new List<User>(Receiveuser.GetAllUsers());
            PrintsForMenuScreen m = new PrintsForMenuScreen(listofusers);
            int ReceiverId = m.ArrowsForFirstScreen(listofusers);
            Console.WriteLine("Type your message and press enter");
            string text = Console.ReadLine();
            MessageManager message = new MessageManager();
            message.MessageToDb(listofusers[ReceiverId - 1].Id, text, StaticProperties.LoggedUserId);
            MessageFileLogger log = new MessageFileLogger();
            log.LogAMessage(StaticProperties.LoggedUserName, listofusers[ReceiverId - 1].UserName, DateTime.Now, text);
        }
        internal protected void ChangePassword()
        {

            Console.Clear();
            PrintLogo.MessagemyWord();
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("Give me your password");
            string pass = Console.ReadLine();
            UserMatchup m = new UserMatchup();
            bool isMatched = m.PasswordMatch(StaticProperties.LoggedUserName, pass);
            if (!isMatched)
            {
                MessageBox.Show("Wrong Pass");
            }
            else
            {
                 
                Console.WriteLine("Password length must be at least 6 characters long, contains at least one digit and contains at least one upper case alphabet");
                Console.Write("Give me the new Password: ");
                pass = Console.ReadLine();  // here i take the password.
                var hasNumber = new Regex(@"[0-9]+");
                var hasUpperChar = new Regex(@"[A-Z]+");
                var hasMinimum8Chars = new Regex(@".{6,}");
                while (true)
                {
                    if (pass != "")
                    {
                        if (!hasNumber.IsMatch(pass) || !hasUpperChar.IsMatch(pass) || !hasMinimum8Chars.IsMatch(pass))
                        {
                            MessageBox.Show("Password length must be at least 6 characters long, contains at least one digit and contains at least one Upper case alphabet");
                            Console.Write("Give me the new Password: ");
                            pass = Console.ReadLine();
                        }
                        else
                        {
                            UserManager man = new UserManager();
                            man.UpdateHashPAssByUserId(StaticProperties.LoggedUserId, pass);
                            break; //when pass is valid.
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password cant be null");//when password is null.
                        Console.Write("Give me a Password: ");
                        pass = Console.ReadLine();
                    }
                }


            }



        }


    }
}
