﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndividualProjectRev3
{
    public static class PrintLogo
    {
        public static void MessagemyWord()
        {
            Console.WriteLine(@" _______         _______                        ______       ");
            Console.WriteLine(@"|   |   |.--.--.|   |   |.-----.--------.-----.|   __ \.----.");
            Console.WriteLine(@"|       ||  |  ||       ||  _  |        |  -__||    __/|  __|");
            Console.WriteLine(@"|__|_|__||___  ||___|___||_____|__|__|__|_____||___|   |____|");
            Console.WriteLine(@"         |_____|                                             ");
            if (StaticProperties.IsSomeoneLogged)
            {

            Console.WriteLine( "                                                              Hello "+StaticProperties.LoggedUserName+"!!!!");
            }
        }

    }
}
