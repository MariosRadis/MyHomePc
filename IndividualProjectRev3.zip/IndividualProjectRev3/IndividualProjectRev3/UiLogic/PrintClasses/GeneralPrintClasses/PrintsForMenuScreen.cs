﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    public class PrintsForMenuScreen
    {
        public int MaxMenuChoises;
        List<string> mylistOfCoices = new List<string>();//this list has the menu properties that will saw up
        List<string> mylistOfMessages = new List<string>();

        public PrintsForMenuScreen(List<string> MenuList)
        {
            mylistOfCoices = MenuList;
        }

        public PrintsForMenuScreen(List<User> MenuList)
        {
            foreach (var item in MenuList)
            {
                mylistOfCoices.Add(item.UserName);
            }
        }

        public PrintsForMenuScreen(List<Message> MenuList)
        {
            UserManager userManager = new UserManager();
            
            foreach (var item in MenuList)
            {
                mylistOfCoices.Add("Message from "+ item.SenderName  +" at " + item.DateAndTime+ " to "+ userManager.FindUsernameByUserId(item.ReceiverId).ToString() + "\n " + item.Text);
            }
        }

        public void PrintsFor(int Menuchoice)
        {
            Console.BackgroundColor = (ConsoleColor)StaticProperties.AppConsoleColor;
            Console.Clear();
            PrintLogo.MessagemyWord();
            int ConsoleColor = StaticProperties.AppMenuChoicesColor;
            for (int i = 0; i <= mylistOfCoices.Count()-1; i++)
            {
                if (i + 1 == Menuchoice)
                    ConsoleColor = StaticProperties.AppHightLightColor;
                else
                    ConsoleColor = StaticProperties.AppMenuChoicesColor;
                    Console.BackgroundColor = (ConsoleColor)ConsoleColor;
                    Console.Write(mylistOfCoices[i].DrawInConsoleBox());              
            }
        }

        public int ArrowsForFirstScreen(List<string> MenuList)
        {
            MaxMenuChoises = MenuList.Count();
            ConsoleKeyInfo keyinfo;
            PrintsForMenuScreen p = new PrintsForMenuScreen(MenuList);
            int MenuLevel = 1;
            p.PrintsFor(MenuLevel);

            do
            {
                keyinfo = Console.ReadKey();
                if (keyinfo.Key == ConsoleKey.DownArrow && MenuLevel == MaxMenuChoises)
                {
                    MenuLevel = 1;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.DownArrow)
                {
                    MenuLevel++;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow && MenuLevel == 1)  
                {
                    MenuLevel = MaxMenuChoises;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow)
                {
                    MenuLevel--;
                    p.PrintsFor(MenuLevel);
                }
                p.PrintsFor(MenuLevel);              
            } while (keyinfo.Key != ConsoleKey.Enter);
            return MenuLevel;
        }

        public int ArrowsForFirstScreen(List<User> MenuList)
        {
            foreach (var item in MenuList)
            {
                mylistOfCoices.Add(item.Id + " " + item.UserName);
            }
            MaxMenuChoises = MenuList.Count();
            ConsoleKeyInfo keyinfo;
            PrintsForMenuScreen p = new PrintsForMenuScreen(MenuList);
            int MenuLevel = 1;
            p.PrintsFor(MenuLevel);

            do
            {
                keyinfo = Console.ReadKey();
                if (keyinfo.Key == ConsoleKey.DownArrow && MenuLevel == MaxMenuChoises)
                {
                    MenuLevel = 1;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.DownArrow)
                {
                    MenuLevel++;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow && MenuLevel == 1) 
                {
                    MenuLevel = MaxMenuChoises;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow)
                {
                    MenuLevel--;
                    p.PrintsFor(MenuLevel);
                }
                p.PrintsFor(MenuLevel);
            } while (keyinfo.Key != ConsoleKey.Enter);


            return MenuLevel;
        }

        public int ArrowsForFirstScreen(List<Message> MenuList)
        {
            
            foreach (var item in MenuList)
            {
                
                mylistOfCoices.Add( item.Text + " "+item.SenderId);
            }
            MaxMenuChoises = MenuList.Count();
            ConsoleKeyInfo keyinfo;
            PrintsForMenuScreen p = new PrintsForMenuScreen(MenuList);
            int MenuLevel = 1;
            p.PrintsFor(MenuLevel);

            do
            {
                keyinfo = Console.ReadKey();
                if (keyinfo.Key == ConsoleKey.DownArrow && MenuLevel == MaxMenuChoises)
                {
                    MenuLevel = 1;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.DownArrow)
                {
                    MenuLevel++;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow && MenuLevel == 1)  
                {
                    MenuLevel = MaxMenuChoises;
                    p.PrintsFor(MenuLevel);
                }
                else if (keyinfo.Key == ConsoleKey.UpArrow)
                {
                    MenuLevel--;
                    p.PrintsFor(MenuLevel);
                }
                p.PrintsFor(MenuLevel);
            } while (keyinfo.Key != ConsoleKey.Enter);
            return MenuLevel;
        }
    }
}

