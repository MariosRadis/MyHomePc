﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndividualProjectRev3
{
    class UiLogicLvl1AccesseAction: UiLogicUserAccess
    {

        internal protected void ReadAllMessages()
        {
            Console.Clear();
            PrintLogo.MessagemyWord();
            Console.Clear();
            MessageManager ReadAll = new MessageManager();
            List<Message> listofmessages = new List<Message>();
            listofmessages = ReadAll.GetAllMessages();
            PrintsForMenuScreen AllMessages = new PrintsForMenuScreen(listofmessages);
            AllMessages.ArrowsForFirstScreen(listofmessages);
        }




    }
}
