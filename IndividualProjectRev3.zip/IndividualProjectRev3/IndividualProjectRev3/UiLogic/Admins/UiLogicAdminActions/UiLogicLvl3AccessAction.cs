﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndividualProjectRev3
{
    class UiLogicLvl3AccessAction:UiLogicLvl2AccessAction
    {
        internal protected void DeleteAMessage()
        {
            MessageManager ForDelete = new MessageManager();
            List<Message> AllMessagesInAList = ForDelete.GetAllMessages();
            PrintsForMenuScreen ChooseaMessage = new PrintsForMenuScreen(AllMessagesInAList);
            int MessageIDForDelete = ChooseaMessage.ArrowsForFirstScreen(AllMessagesInAList);
            ForDelete.DeleteAMessageByMessageId(AllMessagesInAList[MessageIDForDelete - 1].Id);
        }
    }
}
