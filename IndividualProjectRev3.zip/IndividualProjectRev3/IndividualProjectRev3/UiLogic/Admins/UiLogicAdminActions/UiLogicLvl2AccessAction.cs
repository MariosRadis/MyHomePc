﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndividualProjectRev3
{
    class UiLogicLvl2AccessAction:UiLogicLvl1AccesseAction
    {
        internal protected void EditAMessage()
        {
            MessageManager ForEdit = new MessageManager();
            List<Message> AllMessagesInaList = ForEdit.GetAllMessages();
            PrintsForMenuScreen ChooseAMessage = new PrintsForMenuScreen(AllMessagesInaList);
            int MessageIDForTextChange = ChooseAMessage.ArrowsForFirstScreen(AllMessagesInaList);
            ForEdit.EditAMessageByMessageId(AllMessagesInaList[MessageIDForTextChange - 1].Id);
        }
    }
}
