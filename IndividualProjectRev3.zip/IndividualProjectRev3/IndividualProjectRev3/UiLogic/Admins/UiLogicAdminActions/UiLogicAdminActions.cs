﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
     class UiLogicAdminActions:UiLogicLvl3AccessAction
    {
   

        internal protected void SetLevelOfAccess()
        {
            UserManager userManager = new UserManager();
            List<User> AllUsers = userManager.GetAllUsers();
            PrintsForMenuScreen ChooseAUSer = new PrintsForMenuScreen(AllUsers);
            int UserIDForAccessChange = ChooseAUSer.ArrowsForFirstScreen(AllUsers);
            List<string> AccessLevels = new List<string>() { "0.SimpleUser Access", "1.Lvl 1 admin(Can view all messages)", "2.Lvl 2 admin(Can view and edit all messages)", "3.Lvl 3 admin(Can view , edit and delete all messages) ", "4" };
            PrintsForMenuScreen ChooseAnAccessLvl = new PrintsForMenuScreen(AllUsers);
            int AccessLvLForAccChange = ChooseAnAccessLvl.ArrowsForFirstScreen(AccessLevels);
            _users = _listOfAllUsers.GetAllUsers();
            userManager.UpdateAUserLevelOfAccessByUserId(_users[UserIDForAccessChange - 1].Id, AccessLvLForAccChange - 1);
        }
        internal protected void UpdateAUser()
        {
            PrintsForMenuScreen x = new PrintsForMenuScreen(_users);
            int UserChoiceForUpdate = x.ArrowsForFirstScreen(_users);
            UserManager forupd = new UserManager();
        }
        internal protected void DeleteAUSer()
        {
            _users = _listOfAllUsers.GetAllUsers();
            PrintsForMenuScreen o = new PrintsForMenuScreen(_users);
            int UserChoiceForDelete = o.ArrowsForFirstScreen(_users);
            UserManager fordel = new UserManager();
            if (StaticProperties.LoggedUserName == _users[UserChoiceForDelete - 1].UserName)
            {
                MessageBox.Show("You can not delete youeself");
            }
            else
            {
                fordel.DeleteAUserByUserId(_users[UserChoiceForDelete - 1].Id);
            }
        }

    }
}
