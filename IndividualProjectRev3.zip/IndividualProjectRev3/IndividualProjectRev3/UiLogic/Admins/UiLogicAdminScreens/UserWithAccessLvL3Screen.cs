﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{

  public static  class UserWithAccessLvL3Screen
    {
       
        public static void PrintAdminLvL3FirstScreen()
        {
            int MenuChoice = 0;
            while (MenuChoice != 7)
            {
                List<string> MenuList = new List<string>() { "View all users", "Read messages", "Send message", "Read all messages", "Edit a massage", "Delete a massage", "Logout" };
                PrintsForMenuScreen l = new PrintsForMenuScreen(MenuList);
                MenuChoice = l.ArrowsForFirstScreen(MenuList);
                UiLogicLvl3AccessAction Lvl3Admin = new UiLogicLvl3AccessAction();
                switch (MenuChoice)
                {
                    case 1:
                        Lvl3Admin.ViewAllUsers();
                        break;
                    case 2:
                        Lvl3Admin.ReadMessage();
                        break;
                    case 3:
                        Lvl3Admin.SendMessage();
                        break;
                    case 4:
                        Lvl3Admin.ReadAllMessages();
                        break;
                    case 5:
                        Lvl3Admin.EditAMessage();
                        break;
                    case 6:
                        Lvl3Admin.DeleteAMessage();
                        break;

                }
            }
        }
    }
}
