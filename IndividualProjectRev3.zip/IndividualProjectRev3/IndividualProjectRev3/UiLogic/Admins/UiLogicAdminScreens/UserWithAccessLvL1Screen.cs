﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{

    public static class UserWithAccessLvL1Screen
    {

        public static void PrintAdminLvL1FirstScreen()
        {
            int MenuChoice = 0;
            while (MenuChoice != 5)
            {     
                List<string> MenuList = new List<string>() { "View all users", "Read messages", "Send message", "Read all messages", "Logout" };
                PrintsForMenuScreen l = new PrintsForMenuScreen(MenuList);
                MenuChoice = l.ArrowsForFirstScreen(MenuList);
                UiLogicLvl1AccesseAction Lvl1Admin = new UiLogicLvl1AccesseAction();

                switch (MenuChoice)
                {
                    case 1:
                        Lvl1Admin.ViewAllUsers();

                        break;
                    case 2:
                        Lvl1Admin.ReadMessage();
                        break;
                    case 3:
                        Console.Clear();
                        Lvl1Admin.SendMessage();
                        break;
                    case 4:
                        Lvl1Admin.ReadAllMessages();
                        break;

                }
            }
        }
    }
}
