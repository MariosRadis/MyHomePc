﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
  
	public static class UserWithAccessLvL2Screen
    {
    
        public static void PrintAdminLvL2FirstScreen()
        {
      

            int MenuChoice = 0;
            while (MenuChoice != 6)
            {
                List<string> MenuList = new List<string>() { "View all users", "Read messages", "Send message", "Read all messages", "Edit a massage", "Logout" };
                PrintsForMenuScreen l = new PrintsForMenuScreen(MenuList);
                MenuChoice = l.ArrowsForFirstScreen(MenuList);
                UiLogicLvl2AccessAction Lvl2Admin = new UiLogicLvl2AccessAction();

                switch (MenuChoice)
                {
                    case 1:
                        Lvl2Admin.ViewAllUsers();
                        break;
                    case 2:
                        Lvl2Admin.ReadMessage();
                        break;
                    case 3:
                        Lvl2Admin.SendMessage();
                        break;

                    case 4:
                        Lvl2Admin.ReadAllMessages();
                        break;
                    case 5:
                        Lvl2Admin.EditAMessage();
                        break;
          
                   
                }
            }
        }
    }
    
}
