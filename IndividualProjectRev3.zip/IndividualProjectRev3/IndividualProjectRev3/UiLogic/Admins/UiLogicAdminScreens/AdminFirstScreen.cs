﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace IndividualProjectRev3
{
    public  class AdminFirstScreen 
    {


        public static void PrintAdminFirstScreen()
        {


            int MenuChoice = 0;
            while (MenuChoice != 9)
            {
                List<string> MenuList = new List<string>() { "View all users", "Read messages", "Send message", "Read all messages", "Edit a message", "Delete a massage", "Set a new admin",  "Delete a user", "Logout" };
                PrintsForMenuScreen l = new PrintsForMenuScreen(MenuList);
                MenuChoice = l.ArrowsForFirstScreen(MenuList);
                UiLogicAdminActions admin = new UiLogicAdminActions();
                switch (MenuChoice)
                {
                    case 1:
                        admin.ViewAllUsers();
                        break;
                    case 2:
                        admin.ReadMessage();
                        break;
                    case 3:
                        admin.SendMessage();
                        break;
                    case 4:
                        admin.ReadAllMessages();
                        break;
                    case 5:
                        admin.EditAMessage();
                        break;
                    case 6:
                        admin.DeleteAMessage();
                        break;
                    case 7:
                        admin.SetLevelOfAccess();
                        break;
                    case 8: 
                        admin.DeleteAUSer();
                        break;                    
                }
            }

        }
    }
}
