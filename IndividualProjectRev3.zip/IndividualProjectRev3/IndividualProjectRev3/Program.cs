﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;                                                                              
using System.Threading.Tasks;                                                                   
using System.Windows.Forms;                                                                     
using System.Net.Mail;                                                                          
using System.Threading;                                                                         
                                                                                                
namespace IndividualProjectRev3                                                                 
{                                                                                               
    class Program                                                                               
    {                                                                                           
        static void Main(string[] args)                                                         
        {
            StaticProperties.IsSomeoneLogged = false;
            Console.OutputEncoding = Encoding.Unicode;
            StaticProperties.TimeForTempLogMillisec = 60000; // how often i want to log the temperature  300000 five   minutes                         
           TemperatureTimer.Timer();      //  i start  the timer to log temperature in a file.                                                    

            List<User> Users = new List<User>();                                                
            UserManager Manager = new UserManager();                                            
            Users = Manager.GetAllUsers();                                                      
                                                                                                
            while (true)                                                                        
            {
                StaticProperties.AppConsoleColor = 9; // default app colors
                StaticProperties.AppHightLightColor = 15;
                StaticProperties.AppMenuChoicesColor = 8;
                int Menuchoice;           
                List<string> MenuList = new List<string>() { "Login", "Create new user", "Forgot password", "Exit" };
                PrintsForMenuScreen s = new PrintsForMenuScreen(MenuList);
                Menuchoice = s.ArrowsForFirstScreen(MenuList);
                int secretCode = -1;
                if (Menuchoice == 1) //login
                {
                    LoginScreen Login = new LoginScreen();
                    Login.GotoLoginScreen();
                }
                else if (Menuchoice == 2) //create new user
                {
                    Createuser user = new Createuser();
                    user.TakeUsers(Users);
                }
                else if (Menuchoice == 3) //forgot password
                {
                    Console.WriteLine("Give me the username");
                    string name = Console.ReadLine();
                    UserMatchup match = new UserMatchup();
                    if (!match.UsernameMatch(name))
                        Console.WriteLine("there is not such a username");// username does not exist
                    else
                    {
                        Console.WriteLine("Give me the submitted mail");
                        string mail = Console.ReadLine();
                        if (!match.EmailMatch(mail, name))
                            MessageBox.Show("This e mail is not matched with user name " + name, "MyHomePc", MessageBoxButtons.OK);
                        else
                        {
                            UserManager u = new UserManager();
                            MailManager m = new MailManager();
                            Random r = new Random();
                            int rand = r.Next(100000, 1000000);
                            m.SendMail(mail, "your password for message app ", "Your secret code is: " + rand); // send a random number via mail
                            Console.WriteLine("Type the secret code sended to you via mail to " + mail);
                            try
                            {
                                secretCode = int.Parse(Console.ReadLine());
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("Invalid Secret code ", "MyHomePc", MessageBoxButtons.OK);
                            }
                            if (secretCode == rand)
                            {
                                UserManager us = new UserManager();
                                us.UpdateHashPAssByUserId(us.FindUserIdByuserName(name),Convert.ToString(rand));
                                MessageBox.Show("Your secret code sended to your mail is your login code.\n If you want to change it please log in and go to change password");
                            }
                        }
                    }
                }
                else if (Menuchoice == 4)//exit
                    Environment.Exit(0);
            }
        }
    }
}





