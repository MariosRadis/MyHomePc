﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace IndividualProjectRev3
{
    class MailManager
    {
        public void SendMail(string receiverMail, string subject, string body)
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("mymessagesapp123@gmail.com");
            mail.To.Add(receiverMail);
            mail.Subject = subject;
            mail.Body = body;
            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("mymessagesapp123@gmail.com", "M331533153315");
            SmtpServer.EnableSsl = true;
            SmtpServer.Send(mail);
            MessageBox.Show("mail Sended");
        }
        public bool IsValid(string emailaddress)
        {
            string email = emailaddress;
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
            {
                MessageBox.Show(email + " is correct");
                return true;
            }
            else
            {
                MessageBox.Show(email + " is incorrect");
                return false;
            }
        }
    }
}
