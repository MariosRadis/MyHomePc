﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;

namespace IndividualProjectRev3
{
    public class UserManager
    {
       
        private List<User> users = new List<User>();
        //prostheei sto db ena neo user
        public User CreateUser(string Username, string email,byte[] hash, byte[]salt)
        {
            User user = new User() { UserName = Username,HashedPass=hash,Salt=salt,LevelOfAccess=0,EmailAddress=email,AppConsoleColor=9,AppMenuChoicesColor=8,AppHightLightColor=15 };
            using (AppContext db = new AppContext())
            {
                db.User.Add(user);
                db.SaveChanges();
            }
            return user;
        }
        //epistrefei ena list me olous tous users
        public List<User> GetAllUsers()
        {

            using (var db = new AppContext())
            {
              var  users = db.User.ToList();
                return users.ToList();
            }
            
        }
        // tha epistrefei ena user name simfona me to id
        public string FindUsernameByUserId(int userId)
        {
            User mes = new User();          
            using (AppContext db = new AppContext())
            {
                return db.User.Where(p => p.Id.Equals(userId)).FirstOrDefault().UserName;
            }
        }
        //deletes a user by userId
        public void DeleteAUserByUserId(int UserId)
        {
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    db.Entry(k).State = EntityState.Deleted;
                    db.SaveChanges();
                }
            }
        }
        //edo allazo level off acces gia kapoion
        public void UpdateAUserLevelOfAccessByUserId(int UserId,int NewLevelOfAccess)
        {
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    k.LevelOfAccess = NewLevelOfAccess;
                    db.SaveChanges();
                }
            }
        }
        //edo allazo Hashpass  gia kapoion
        public void UpdateHashPAssByUserId(int UserId, string pass)
        {
           
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    k.HashedPass = Passhash.Hash(pass,k.Salt);
                    db.SaveChanges();
                    MessageBox.Show("The password changed successfully");
                }
            }
        }
        //edo allazo AppConsoleColor
        public void UpdateAppConsoleColor(int UserId, int NewColor)
        {
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    k.AppConsoleColor = NewColor;
                    db.SaveChanges();
                }
            }
        }
        //edo allazo AppMenuChoicesColor
        public void UpdateAppMenuChoicesColor(int UserId, int NewColor)
        {
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    k.AppMenuChoicesColor = NewColor;
                    db.SaveChanges();
                }
            }
        }
        //edo chekarei to lvl off access kai epistrefei se int tin timi tou
        public int CheckLvLOffAccess(string Username)
        {
            using (var db = new AppContext())
            {
                return db.User.Where(p => p.UserName.Equals(Username)).FirstOrDefault().LevelOfAccess;
            }
        }
        //edo apothikeuo to background color pou thelei na exei o xristis
        public void UpdateBackgroundColorByUserId(int UserId, int Color)
        {
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    k.AppConsoleColor = Color;
                    db.SaveChanges();
                }
            }
        }
        //edo allazo AppHightLightColor
        public void UpdateAppHightLightColor(int UserId, int NewColor)
        {
            using (AppContext db = new AppContext())
            {
                var k = db.User.Find(UserId);
                if (k != null)
                {
                    k.AppHightLightColor = NewColor;
                    db.SaveChanges();
                }
            }
        }
        //epistrefei ton arithmo tou background color simfona me to user id
        public int FindBackgroundByUserId(int userId)
        {
            using (AppContext db = new AppContext())
            {
                return db.User.Where(p => p.Id.Equals(userId)).FirstOrDefault().AppConsoleColor;
            }
        }
        public int FindUserIdByuserName(string name)
        {
            using (AppContext db = new AppContext())
            {
                return db.User.Where(p => p.UserName.Equals(name)).FirstOrDefault().Id;
            }
        }
        //Here is the highlight color by user id
        public int FindHightLightColorByUserId(int userId)
        {
            using (AppContext db = new AppContext())
            {
                return db.User.Where(p => p.Id.Equals(userId)).FirstOrDefault().AppHightLightColor;
            }
        }
        //find a hash by userid
        public byte[] FindHashByUserId(int userId)
        {
            using (AppContext db = new AppContext())
            {
                return db.User.Where(p => p.Id.Equals(userId)).FirstOrDefault().HashedPass;
            }
        }
        //find a salt by userid
        public byte[] FindASaltByUserId(int userId)
        {
            using (AppContext db = new AppContext())
            {
                return db.User.Where(p => p.Id.Equals(userId)).FirstOrDefault().Salt;
            }
        }

    }
}
