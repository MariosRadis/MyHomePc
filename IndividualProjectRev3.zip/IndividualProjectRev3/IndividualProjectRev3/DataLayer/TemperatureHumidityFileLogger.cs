﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace IndividualProjectRev3
{
    public class TemperatureHumidityFileLogger
    {
        string path = @"TemperatureHumidityLogFile.txt";
        //Create a file if it does not exist (constractor)
        public TemperatureHumidityFileLogger()
        {
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
                MessageBox.Show("Created a new file at \n" + @"C:\Users\margi\OneDrive\Desktop\C#\MEGA\IndividualProjectRev3\IndividualProjectRev3\bin\Debug");
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine("This is a Files that logs Temperature! Created at  " + DateTime.Now);
                }
            }
        }
        // append the file with the temerature and humidity info
        public void LogTempHum(DateTime time, string temp)
        {
            try
            {


                using (StreamWriter outputFile = new StreamWriter(Path.Combine(path), true))
                {
                    outputFile.WriteLine(" at " + time + " temperature was:  " + temp);
                }
            }
            catch (Exception)
            {

               
            }

        }
    }
}
