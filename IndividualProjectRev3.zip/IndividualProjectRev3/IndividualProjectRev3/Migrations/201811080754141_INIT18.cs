namespace IndividualProjectRev3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class INIT18 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "AppConsoleColor", c => c.Int(nullable: false));
            AddColumn("dbo.Users", "AppMenuChoicesColor", c => c.Int(nullable: false));
            AddColumn("dbo.Users", "AppHightLightColor", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Users", "AppHightLightColor");
            DropColumn("dbo.Users", "AppMenuChoicesColor");
            DropColumn("dbo.Users", "AppConsoleColor");
        }
    }
}
