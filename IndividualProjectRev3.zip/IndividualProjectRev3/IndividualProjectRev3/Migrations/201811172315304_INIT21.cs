namespace IndividualProjectRev3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class INIT21 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Users", "HashedPass", c => c.Binary());
            AlterColumn("dbo.Users", "Salt", c => c.Binary());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Users", "Salt", c => c.Byte(nullable: false));
            AlterColumn("dbo.Users", "HashedPass", c => c.Byte(nullable: false));
        }
    }
}
