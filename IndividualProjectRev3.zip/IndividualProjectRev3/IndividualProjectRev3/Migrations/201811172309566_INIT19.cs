namespace IndividualProjectRev3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class INIT19 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "HashedPass", c => c.Byte(nullable: false));
            AddColumn("dbo.Users", "ProfileStatus", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Users", "ProfileStatus");
            DropColumn("dbo.Users", "HashedPass");
        }
    }
}
